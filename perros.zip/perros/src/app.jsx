import React, { useState } from 'react';
import './App.css'; // Importar estilos CSS personalizados

const App = () => {
  const [raza, setRaza] = useState('');
  const [razas, setRazas] = useState([]);
  const [razasSeleccionadas, setRazasSeleccionadas] = useState([]);

  const handleInputChange = (event) => {
    setRaza(event.target.value);
  };

  const handleBuscarClick = () => {
    fetch(`https://dog.ceo/api/breeds/list/all`)
      .then(response => response.json())
      .then(data => {
        const razas = Object.keys(data.message);
        setRazas(razas.filter(r => r.toLowerCase().includes(raza.toLowerCase())));
      })
      .catch(error => {
        console.error('Error al buscar las razas de perros:', error);
      });
  };

  const handleRazaClick = (raza) => {
    fetch(`https://dog.ceo/api/breed/${raza}/images/random`)
      .then(response => response.json())
      .then(data => {
        setRazasSeleccionadas(prevState => [
          ...prevState,
          { nombre: raza, imagen: data.message }
        ]);
      })
      .catch(error => {
        console.error('Error al obtener la imagen del perro:', error);
      });
  };

  return (
    <div className="container mt-5">
      <div className="jumbotron">
        <h1 className="display-4 text-center">Búsqueda de Razas de Perros</h1>
      </div>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control"
          placeholder="Buscar una raza de perro..."
          value={raza}
          onChange={handleInputChange}
        />
        <div className="input-group-append">
          <button className="btn btn-primary" type="button" onClick={handleBuscarClick}>Buscar</button>
        </div>
      </div>
      <div className="row">
        {razas.map((raza, index) => (
          <div key={index} className="col-3">
            <div className="card mb-3">
              <div className="card-body">
                <h5 className="card-title">{raza}</h5>
                <button className="btn btn-primary btn-block" onClick={() => handleRazaClick(raza)}>Ver</button>
              </div>
            </div>
          </div>
        ))}
      </div>
      {razasSeleccionadas.map((raza, index) => (
        <div key={index} className="modal" tabIndex="-1" role="dialog">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">{raza.nombre}</h5>
                <button type="button" className="close" onClick={() => setRazasSeleccionadas(prevState => prevState.filter((_, i) => i !== index))}>
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div className="modal-body">
                <img src={raza.imagen} alt={raza.nombre} className="img-fluid mb-3" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default App;
